 <!--------------- Sidebar Open -------------------->
        <div class="col-sm-4">
            <div class="sidebar">
                  <?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>   
                                           <?php endif; ?> 
                
             </div>
            <!---- (IT MUST) Sidebar Devider Open ---->
            <div class="sidebar-devider"></div>
            <!---- (IT MUST) Sidebar Devider Open ---->
        </div>
        <!--------------- Sidebar Close -------------------->