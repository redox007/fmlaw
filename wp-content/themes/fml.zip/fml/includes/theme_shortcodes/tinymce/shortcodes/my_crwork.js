frameworkShortcodeAtts={
	attributes:[
			{
                label:"How many Post to show?",
                id:"num",
                help:"This is how many Works will be displayed."
            },
            {
                label:"Auto",
                id:"auto",
                controlType:"select-control", 
                selectValues:['true', 'false'],
                defaultValue: 'false', 
                defaultText: 'false',
                help:"Carousel auto on/off."
            }
	],
	defaultContent:"",
	shortcode:"crwork"
};