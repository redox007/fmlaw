frameworkShortcodeAtts={
	attributes:[
			{
				label:"Left Content Or Right Content?",
				id:"type",
				controlType:"select-control", 
				selectValues:['left', 'right'],
				defaultValue: 'left', 
				defaultText: 'left',
				help:"Content maker Left Or Right."
			}
	],
	defaultContent:"Your content Goes here",
    shortcode:"box",
    shortcodeType: "text-replace"
};