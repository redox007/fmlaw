<?php if (is_active_sidebar('wwd')) : ?>
    <?php dynamic_sidebar('wwd'); ?>
<?php endif; ?>