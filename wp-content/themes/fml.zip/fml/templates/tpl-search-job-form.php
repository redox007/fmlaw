<header id="job-seeker">
    <div id="search-area" class="header-content ">
         <h2 class="text-center text-uppercase font-capa text-white section-heading"><?php the_subtitle(); ?></h2>
<!--        <form class="form-inline" action="<?php echo site_url(); ?>">
            <div class="form-group">
                <label class="sr-only" for="exampleInputKeywords">Keywords</label>
                <input type="text" name="keyword" class="form-control" id="exampleInputKeywords" placeholder="Keywords">
            </div>
            <div class="form-group">
                <label class="sr-only" for="exampleInputPractice">Practice Area</label>
                <input type="text" name="practice_area" class="form-control" id="exampleInputPractice" placeholder="Practice Area">
            </div>
            <div class="form-group">
                <label class="sr-only" for="exampleInputWorkType">Work type</label>
                <input type="text" name="work_type" class="form-control" id="exampleInputWorkType" placeholder="Work type">
            </div>
            <div class="form-group">
                <label class="sr-only" for="exampleInputLocation">Location</label>
                <input type="text" name="location" class="form-control" id="exampleInputLocation" placeholder="Location">
            </div>
            <input type="hidden" name="s" />
            <button type="submit" class="btn button-search"><span class="search-text">Search</span> <i class="fa fa-search" aria-hidden="true"></i></button>
        </form>-->
    </div> 
</header>