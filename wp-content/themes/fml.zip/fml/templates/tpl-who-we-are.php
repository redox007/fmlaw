<?php if (is_active_sidebar('wwr')) : ?>
    <?php dynamic_sidebar('wwr'); ?>
<?php endif; ?>